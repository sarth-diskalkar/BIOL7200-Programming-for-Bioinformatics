#!/usr/bin/env python3

import argparse
import os
import sys

import magnumopus

def read_fasta(fasta_string: str) -> dict[str, str]:
	fasta_dict = {}
	seq_lines = []
	for line in fasta_string.split("\n"):
		if len(line) == 0:
			continue
		if line[0] == ">":
			if seq_lines:
				fasta_dict[header] = "".join(seq_lines)
				seq_lines = []
			header = line.split()[0][1:] # word after ">"
			continue

		seq_lines.append(line.strip())
	fasta_dict[header] = "".join(seq_lines)
	return fasta_dict

def rev_comp(seq: str) -> str:
    revs = {
        "A": "T",
        "T": "A",
        "C": "G",
        "G": "C"
    }

    rev_bases = [revs[base.upper()] for base in seq[::-1]]
    rev_seq = "".join(rev_bases)
    return rev_seq


def parse_args():

	p = argparse.ArgumentParser(
		description="Perform in-silico PCR on two assemblies and align the amplicons"
		)
	p.add_argument(
		"-1", dest="assembly1", required=True, type=str,
		help="Path to the first assembly file"
		)
	p.add_argument(
		"-2", dest="assembly2", required=True, type=str,
		help="Path to the second assembly file"
		)
	p.add_argument(
		"-p", dest="primers", required=True, type=str,
		help="Path to the primer file"
		)
	p.add_argument(
		"-m", dest="max_amplicon_size", required=True, type=int,
		help="maximum amplicon size for isPCR"
		)
	p.add_argument(
		"--match", required=True, type=int,
		help="match score to use in alignment"
		)
	p.add_argument(
		"--mismatch", required=True, type=int,
		help="mismatch penalty to use in alignment"
		)
	p.add_argument(
		"--gap", required=True, type=int,
		help="gap penalty to use in alignment"
		)

	return p.parse_args()

def main():
	args = parse_args()
	assembly_file1 = args.assembly1
	assembly_file2 = args.assembly2
	primer_file = args.primers
	max_amp_size = args.max_amplicon_size

	amplicons = []
	for assembly in [assembly_file1, assembly_file2]:
		amp = magnumopus.ispcr(primer_file, assembly, max_amp_size)
		amplicons.append(amp)
	
	amplicon_dict = read_fasta("\n".join(amplicons))

	headers = [k for k in amplicon_dict]
	seqs = [v for v in amplicon_dict.values()]

	f_aln, fwd = magnumopus.needleman_wunsch(seqs[0], seqs[1], args.match,
												args.mismatch, args.gap)
	r_aln, rev = magnumopus.needleman_wunsch(seqs[0], rev_comp(seqs[1]), args.match,
												args.mismatch, args.gap)

	if fwd > rev:
		print("\n".join(f_aln) + "\n")
		print(fwd)
	else:
		print("\n".join(r_aln) + "\n")
		print(rev)

if __name__ == '__main__':
	main()


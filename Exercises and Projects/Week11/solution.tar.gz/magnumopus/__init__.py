from magnumopus.ispcr import ispcr
from magnumopus.nw import needleman_wunsch

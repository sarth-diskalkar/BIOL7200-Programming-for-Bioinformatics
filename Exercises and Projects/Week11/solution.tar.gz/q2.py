#!/usr/bin/env python3

import magnumopus

seq1 = "CTTCTCGTCGGTCTCGTGGTTCGGGAAC"
seq2 = "CTTTCATCCACTTCGTTGCCCGGGAAC"

aln, score = magnumopus.needleman_wunsch(seq1, seq2, 1, -1, -1)

possible_alns = {('CTTCTCGT-CGGTCTCGTGGTTCGGGAAC', 'CTT-TCATCCACT-TCGTTGCCCGGGAAC'), ('CTTCTCGTC-GGTCTCGTGGTTCGGGAAC', 'CTT-TCATCCACT-TCGTTGCCCGGGAAC'), ('CTTCTCGTCG-GTCTCGTGGTTCGGGAAC', 'CTT-TCATCCACT-TCGTTGCCCGGGAAC'), ('CTTCTCGTCGG-TCTCGTGGTTCGGGAAC', 'CTT-TCATCCACT-TCGTTGCCCGGGAAC'), ('CTTCTCGTCGGTC-TCGTGGTTCGGGAAC', 'CTT-TCATC-CACTTCGTTGCCCGGGAAC'), ('CTTCTCGTCGGTC-TCGTGGTTCGGGAAC', 'CTT-TCATCC-ACTTCGTTGCCCGGGAAC'), ('CTTCTCGTCGGTC-TCGTGGTTCGGGAAC', 'CTT-TCATCCA-CTTCGTTGCCCGGGAAC'), ('CTTCTCGTCGGTCT-CGTGGTTCGGGAAC', 'CTT-TCATC-CACTTCGTTGCCCGGGAAC'), ('CTTCTCGTCGGTCT-CGTGGTTCGGGAAC', 'CTT-TCATCC-ACTTCGTTGCCCGGGAAC'), ('CTTCTCGTCGGTCT-CGTGGTTCGGGAAC', 'CTT-TCATCCA-CTTCGTTGCCCGGGAAC')}
print("\n".join(aln) + "\n")
print(aln in possible_alns or aln[::-1] in possible_alns)
print(score)


# # All alignments
# alns, score = magnumopus.needleman_wunsch(seq1, seq2, 
# 										  1, -1, -1, 
# 										  all_alns=True)

# def pretty_aln(seq1, seq2):
# 	annot = []
# 	for a,b in zip(seq1, seq2):
# 		if a == b:
# 			annot.append("|")
# 		else:
# 			annot.append(" ")

# 	print(seq1)
# 	print("".join(annot))
# 	print(seq2)


# for aln in alns:
# 	pretty_aln(*aln)
# 	print()


#!/usr/bin/env python3

import os
import sys

from magnumopus import (
	DistanceMatrix,
	SeqEntry,
	ISPCR
)

primer_file = "data/16s_tree/primers/general_16S_515f_806r.fna"
assemblies_dir = "data/16s_tree/assemblies/"

amplicons = {}

for assembly_file in os.listdir(assemblies_dir):
	sample = assembly_file.strip(".fna")
	assembly_path = assemblies_dir + "/" + assembly_file
	amps = ISPCR(primer_file, assembly_path, 2000)
	amplicons[sample] = amps.amplicons[0]

samples = []
seqs = []
for samp, seq in amplicons.items():
	samples.append(samp)
	seqs.append(seq)
	
x = DistanceMatrix.nw_dist(samples, seqs)

x.upgma()

print(x.tree)

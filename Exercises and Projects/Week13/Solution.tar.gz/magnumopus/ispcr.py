#!/usr/bin/env python3

import subprocess
import os
import sys
from collections import defaultdict
import tempfile

class SeqEntry:
	def __init__(self, header: str, seq: str):
		self.header = header
		self.seq = seq

	def __str__(self):
		return f">{self.header}\n{self.seq}"

	def __len__(self):
		return len(self.seq)

	@staticmethod
	def rev_comp(seq: str):
		revs = {
			"A": "T",
			"T": "A",
			"C": "G",
			"G": "C",
			"N": "N"
		}

		rev_bases = [revs[base.upper()] for base in seq[::-1]]
		rev_seq = "".join(rev_bases)
		return rev_seq


	@classmethod
	def from_single_fasta(cls, fasta_str: str):
		lines = fasta_str.split("\n")
		header = lines[0][1:]
		seq = "".join(lines[1:-1])
		return cls(header, seq)


	@classmethod
	def from_multi_fasta(cls, fasta_str: str):
		entries = fasta_str.split(">")[1:]
		for entry in entries:
			lines = entry.split("\n")
			header = lines[0]
			seq = "".join(lines[1:-1])
			yield cls(header, seq)


class BLASTResult:
	def __init__(self, line):
		""" Read line of BLAST output. Assume -outfmt '6 std qlen'"""
		# store for printing representation
		self._line = line
		# Store the basic field data
		cols = line.split()
		self.qseqid = cols[0]
		self.sseqid = cols[1]
		self.pident = float(cols[2])
		self.length = int(cols[3])
		self.mismatch = int(cols[4])
		self.gapopen = int(cols[5])
		self.qstart = int(cols[6])
		self.qend = int(cols[7])
		self.sstart = int(cols[8])
		self.send = int(cols[9])
		self.evalue = float(cols[10])
		self.bitscore = float(cols[11])
		self.qlen = int(cols[12])
		
		# Store some convenience data
		self.prcnt_length = 100*self.length/self.qlen
		if self.sstart < self.send:
			self.reverse = False
		else:
			self.reverse = True
		
		if self.qstart == 1 and self.qend == self.qlen:
			self.full_length = True
		else:
			self.full_length = False
	
	def good_hit(self, percent_id: float, percent_len: float) -> bool:
		if self.pident >= percent_id and self.prcnt_length >= percent_len:
			return True
		else:
			return False
	
	
	def check_pair(self, other_hit: 'BLASTResult', max_amp_size: int) -> bool:
		"""Check if this result would make an amplicon with another result, assuming both anneal"""
		
		# call primer with lower index "p_forward" and other "p_reverse"
		if self.sstart < other_hit.sstart:
			p_forward = self
			p_reverse = other_hit
		else:
			p_forward = other_hit
			p_reverse = self
		
		# check orientation (perhaps could have added a "forward" attribute...)
		if p_forward.reverse or not p_reverse.reverse:
			return False
		
		# check distance between hits
		if p_reverse.send - p_forward.send > max_amp_size:
			return False
		
		# otherwise all good
		return True


	def __gt__(self, other): # for sorting
		if (self.sseqid, self.sstart) > (other.sseqid, other.sstart):
			return True
		else:
			return False

	def __str__(self):
		return self._line

	def __repr__(self):
		return f"{self.__class__.__name__}({self._line})"



class ISPCR:
	def __init__(self, primer_file: str, assembly_file: str, max_amplicon_size: int,
				 percent_id: float = 70., percent_len: float = 90.):
		self.primer_file = primer_file
		self.assembly_file = assembly_file
		self.max_amplicon_size = max_amplicon_size
		self.percent_id = percent_id,
		self.percent_len = percent_len
		self.amplicons: list[SeqEntry] = None
		self._run()

	def _run(self):
		self._find_annealing()
		self._filter_hits()
		self._identify_paired_hits()
		self._get_amplicons()

	def _find_annealing(self):
		blast_command = ["blastn"]
		blast_command += ["-query", self.primer_file]
		blast_command += ["-subject", self.assembly_file]
		blast_command += ["-task", "blastn-short"]
		blast_command += ["-outfmt", "6 std qlen"]
		blast_results, _ = run_external(blast_command)
		self._all_hits = [BLASTResult(i) for i in blast_results.split("\n") if len(i) != 0]

	def _filter_hits(self):
		good_hits = [hit for hit in self._all_hits if hit.good_hit(70, 90)]
		# self._good_hits = sorted(good_hits, key=lambda x: (x.qseqid, x.sstart))
		self._good_hits = sorted(good_hits)


	def _identify_paired_hits(self):
		self._hit_pairs = []
		for i in range(len(self._good_hits)-1):
			a_hit = self._good_hits[i]
			for j in range(i+1, len(self._good_hits)):
				b_hit = self._good_hits[j]
				if a_hit.check_pair(b_hit, self.max_amplicon_size):
					self._hit_pairs.append((a_hit, b_hit))


	def _get_amplicons(self) -> str:
		amplicons = []
		bed = []
		for f_hit, r_hit in self._hit_pairs:
			bed.append(f"{f_hit.sseqid}\t{f_hit.send}\t{r_hit.send-1}\n")

		bed_string = "".join(bed)
		with tempfile.NamedTemporaryFile(mode='w+') as temp:
			temp.write(bed_string)
			temp.seek(0)
			seqtk_command = ["seqtk", "subseq", self.assembly_file]
			seqtk_command += [temp.name]
			amplicons, stderr = run_external(seqtk_command)
			self.amplicons = [a for a in SeqEntry.from_multi_fasta(amplicons)]

	def __str__(self):
		return "\n".join([str(a) for a in self.amplicons])


def run_external(command: list[str], stdin=None) -> tuple[str, str]:
	"""run external command and return stout and stderr
	"""
	if stdin is None:
		result = subprocess.run(command, capture_output=True, text=True)
	else:
		result = subprocess.run(command, capture_output=True, text=True, input=stdin)

	return result.stdout, result.stderr


def test():
	primer_str = ">515F Forward Primer (Parada)\nGTGYCAGCMGCCGCGGTAA\n>806R Reverse Primer (Apprill)\nGGACTACNVGGGTWTCTAAT\n"
	assembly_str = ">contig\nGTGCCAGCAGCCGCGGTAA" + "ATCG"*10 + "ATTAGAAACCCCTGTAGTCC"

	with (tempfile.NamedTemporaryFile(mode='w+') as primer_file,
		tempfile.NamedTemporaryFile(mode='w+') as assembly_file
	):
		primer_file.write(primer_str)
		primer_file.seek(0)
		assembly_file.write(assembly_str)
		assembly_file.seek(0)
		x = ISPCR(primer_file.name, assembly_file.name, 2000)
	print(x)

if __name__ == '__main__':
	test()
	

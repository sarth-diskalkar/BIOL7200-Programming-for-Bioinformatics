#!/usr/bin/env python3

import sys
import shutil

# We'll use binary flags to encode direction: up, left, diagonal
D_FLAGS = {
	"up": 4,
	"left": 2,
	"diag": 1
}

class Align:
	def __init__(self, seqa: str, seqb: str, params: dict[str, str],
				 alna: str = None, alnb: str = None, score: int = None,
				 all_alns: list[tuple[str]] = None):
		self.seqa = seqa
		self.seqb = seqb
		self.params = params
		self.alna = alna
		self.alnb = alnb
		self.score = score
		self.lena = len(seqa)
		self.lenb = len(seqb)
		self.score_mat = [[0 for _ in range(self.lenb+1)] for _ in range(self.lena+1)]
		self.point_mat = [[0 for _ in range(self.lenb+1)] for _ in range(self.lena+1)]
		self.all_alns = all_alns

	@classmethod
	def needleman_wunsch(cls, seqa: str, seqb: str, match: float = 1,
						 mismatch: float = -1, gap: float = -1,
						 all_paths: bool = False):
		x = cls(seqa, seqb, {"match": match, "mismatch": mismatch, "gap": gap})
		x.fill_matrix("nw", match, mismatch, gap)
		x.traceback(all_paths)
		return x


	def print_mats(self, point_mat: bool = False) -> None:
		if point_mat:
			mat = self.point_mat
			char_dict = {
				1: "\\", # diagonal
				2: "-", # left
				3: ">", # diag + left
				4: "'", # up
				5: "V", # diag + up
				6: "+", # up + left
				7: "*" # all
			}
		else:
			mat = self.score_mat
			char_dict = {}
		# get max chars in cells
		max_chars = 0
		for row in mat:
			for cell in row:
				if len(str(cell)) > max_chars:
					max_chars = len(str(cell))
		row_divider = " +" + "+".join(["-"*max_chars for _ in range(len(mat[0]))]) + "+"
		seq_delim = " "*max_chars
		top_line = seq_delim.join([" "]*2 + [i for i in self.seqb])
		to_print = [top_line]
		to_print.append(row_divider)
		for i, row in enumerate(mat):
			if i == 0:
				seq = " "
			else:
				seq = self.seqa[i-1]
			row_contents = [f"{seq}|"]
			for j, cell in enumerate(row):
				contents_str = str(char_dict.get(cell, cell))
				cell_string = " " * (max_chars-len(contents_str)) + contents_str
				row_contents.append(f"{cell_string}|")
			to_print.append("".join(row_contents))
			to_print.append(row_divider)
		print("\n".join(to_print))


	def print_alns(self, idx: int|None = None):
		if idx:
			alns = [self.all_alns[idx]]
		else:
			alns = self.all_alns

		out_lines = [""]
		for n, a in enumerate(alns):
			out_lines.append(f"Alignment: {n+1}")
			out_lines += self._format_print(a)

		print("\n".join(out_lines))


	def _format_print(self, aln: tuple[str]):
		# Get terminal width for proper wrapping in long sequences
		# Adjust for prefix addition
		print_len = shutil.get_terminal_size().columns - 2
		if len(aln[0]) > print_len:
			prefixes = ["1 ", "  ", "2 "]
		else:
			prefixes = [""]*3

		aln_list = []
		for a,b in zip(*aln):
			if a == b:
				aln_list.append("|")
			else:
				aln_list.append(" ")

		aln_string = "".join(aln_list)

		out_lines = []
		for i in range(0, len(aln_string), print_len):
			out_lines.append(prefixes[0] + aln[0][i:i+print_len])
			out_lines.append(prefixes[1] + aln_string[i:i+print_len])
			out_lines.append(prefixes[2] + aln[1][i:i+print_len])
			out_lines.append("")
		return out_lines


	def fill_matrix(self, algorithm: str, match: float,
					mismatch: float, gap: float) -> None:
		""" Fill a score and direction matrix 

		Can be done using needleman-wunsch or Smith-Waterman algorithm approach
		"""
		if algorithm == "nw":
			self.nw_fill(match,	mismatch, gap)

	def nw_fill(self, match: float, mismatch: float, gap: float) -> None:
		# fill first row and column
		for i in range(1, self.lenb+1):
			self.score_mat[0][i] = gap*i
			self.point_mat[0][i] = D_FLAGS["left"]

		for i in range(1, self.lena+1):
			self.score_mat[i][0] = gap*i
			self.point_mat[i][0] = D_FLAGS["up"]

		# fill the matrices
		for i in range(1, self.lena+1):
			base_a = self.seqa[i-1]
			for j in range(1, self.lenb+1):
				base_b = self.seqb[j-1]
				if base_a == base_b:
					match_mismatch = match
				else:
					match_mismatch = mismatch

				up = self.score_mat[i-1][j] + gap
				left = self.score_mat[i][j-1] + gap
				diag = self.score_mat[i-1][j-1] + match_mismatch

				best_score = max(up, left, diag)
				self.score_mat[i][j] = best_score

				if up == best_score:
					self.point_mat[i][j] += D_FLAGS["up"]
				if left == best_score:
					self.point_mat[i][j] += D_FLAGS["left"]
				if diag == best_score:
					self.point_mat[i][j] += D_FLAGS["diag"]

		self.score = self.score_mat[-1][-1]


	def traceback(self, all_paths=False):
		# initialize matrix to store all paths
		self.aln_score = self.score_mat[self.lena][self.lenb]
		self.all_alns = [i for i in self.follow_path(self.lena, self.lenb, [], [], all_paths)]
		self.alna, self.alnb = self.all_alns[0]


	def follow_path(self, i: int,	j: int,	aln_a_so_far: list[str], 
					aln_b_so_far: list[str], all_paths: bool = False) -> tuple[str, str]:
		# End condition
		if i == 0 and j == 0:
			yield "".join(aln_a_so_far[::-1]), "".join(aln_b_so_far[::-1])

		direction_bits = self.point_mat[i][j]
		# var to store when a path has been followed when all_paths == False
		followed = False
		if D_FLAGS["diag"] & direction_bits:
			if not all_paths:
				followed = True
			new_i = i - 1
			new_j = j - 1
			new_aln_a = aln_a_so_far + [self.seqa[new_i]]
			new_aln_b = aln_b_so_far + [self.seqb[new_j]]
			for a in self.follow_path(new_i, new_j, new_aln_a, new_aln_b, all_paths):
				yield a
		if D_FLAGS["up"] & direction_bits and not followed:
			if not all_paths:
				followed = True
			new_i = i - 1
			new_aln_a = aln_a_so_far + [self.seqa[new_i]]
			new_aln_b = aln_b_so_far + ["-"]
			for a in self.follow_path(new_i, j, new_aln_a, new_aln_b, all_paths):
				yield a
		if D_FLAGS["left"] & direction_bits and not followed:
			new_j = j - 1
			new_aln_a = aln_a_so_far + ["-"]
			new_aln_b = aln_b_so_far + [self.seqb[new_j]]
			for a in self.follow_path(i, new_j, new_aln_a, new_aln_b, all_paths):
				yield a


if __name__ == '__main__':
	x = Align.needleman_wunsch("TTAATTATT", "TTATTAATT", all_paths=True)
	x.print_alns()

from copy import deepcopy

from magnumopus import (
	SeqEntry,
	Align
)

class Matrix:
	def __init__(self, rows: int, cols: int):
		self._matrix = [[0 for _ in range(cols)] for _ in range(rows)]

	def __getitem__(self, key):
		return self._matrix[key]

	def __iter__(self):
		for row in self._matrix:
			yield row

	def __len__(self):
		return len(self._matrix)

	def __str__(self):
		# get max chars in cells
		max_chars = 0
		for row in self._matrix:
			for cell in row:
				if len(str(cell)) > max_chars:
					max_chars = len(str(cell))
		row_divider = "+" + "+".join(["-"*max_chars for _ in range(len(self._matrix[0]))]) + "+"
		to_print = [row_divider]
		for i, row in enumerate(self._matrix):
			row_contents = ["|"]
			for j, cell in enumerate(row):
				contents_str = str(cell)
				cell_string = " " * (max_chars-len(contents_str)) + contents_str
				row_contents.append(f"{cell_string}|")
			to_print.append("".join(row_contents))
			to_print.append(row_divider)
		return "\n".join(to_print)

	@property
	def nrows(self):
		return len(self._matrix)

	@property
	def ncols(self):
		return len(self._matrix[0])

	def del_col(self, idx: int):
		for row in self._matrix:
			del row[idx]

	def del_row(self, idx: int):
		del self._matrix[idx]

	def get_row(self, idx: int):
		return self._matrix[idx]

	def get_col(self, idx: int):
		return [row[idx] for row in self._matrix]

	def set_row(self, idx: int, new_row: list):
		if len(self.get_col(idx)) != len(new_row):
			raise ValueError("Provided row is not the same size as matrix")
		self._matrix[idx] = new_row

	def set_col(self, idx: int, new_col: list):
		if len(self.get_col(idx)) != len(new_col):
			raise ValueError("Provided column is not the same size as matrix")
		for i in range(len(self._matrix)):
			self._matrix[i][idx] = new_col[i]

	def average(self, idx_1: int, idx_2: int, axis: str = 'row'):
		"""Return the average of each cell in two rows or cols"""
		if axis == 'row':
			row_1 = self.get_row(idx_1)
			row_2 = self.get_row(idx_2)
			av = [(a+b)/2 for a,b in zip(row_1, row_2)]
			return av

		elif axis == 'col':
			col_1 = self.get_col(idx_1)
			col_2 = self.get_col(idx_2)
			av = [(a+b)/2 for a,b in zip(col_1, col_2)]
			return av

		else:
			raise ValueError("axis must be either 'row' or 'col'")

	def fill_diagonal(self, val):
		for i in range(len(self)):
			self._matrix[i][i] = val

	def min(self):
		min_val = self._matrix[0][1]
		min_idx = (0, 1)
		for i in range(self.nrows):
			for j in range(i+1, self.ncols):
				if self._matrix[i][j] < min_val:
					min_val = self._matrix[i][j]
					min_idx = (i, j)

		return min_val, min_idx

	def max(self):
		max_val = self._matrix[0][1]
		max_idx = (0, 1)
		for i in range(self.nrows):
			for j in range(i+1, self.ncols):
				if self._matrix[i][j] > max_val:
					max_val = self._matrix[i][j]
					max_idx = (i, j)

		return max_val, max_idx



class DistanceMatrix:
	def __init__(self, samples: list[str], amplicons: dict[str, SeqEntry]):
		self._samples = samples
		self._amplicons = amplicons

		self._distmat: Matrix = Matrix(len(samples), len(samples))

		# to set later
		self._tree: str = None # newick format tree

	def __str__(self):
		return str(self._distmat)

	@property
	def samples(self):
		return self._samples

	@property
	def amplicons(self):
		return self._amplicons

	@property
	def distmat(self):
		return deepcopy(self._distmat)

	@property
	def tree(self):
		if self._tree is None:
			raise ValueError("Tree has not yet been inferred. Infer a tree first.")
		return self._tree

	@classmethod
	def nw_dist(cls, samples: list[str], seqs: list[SeqEntry], **kwargs):
		"""Build a distance matrix using Needleman-Wunsch alignment scores
		
		Takes **kwargs to be passed to the Needleman-Wunsch algorithm
		"""
		dmat = cls(samples, seqs)
		for i in range(len(seqs)):
			for j in range(i+1, len(seqs)):
				seqa = seqs[i]
				seqb = seqs[j]
				aln_f = Align.needleman_wunsch(seqa.seq, seqb.seq, **kwargs)
				aln_r = Align.needleman_wunsch(seqa.seq, SeqEntry.rev_comp(seqb.seq), **kwargs)
				if aln_f.score > aln_r.score:
					aln = aln_f
				else:
					aln = aln_r

				max_score = max([len(seqa), len(seqb)])*aln.params["match"]
				dist = max_score - aln.score
				dmat._distmat[i][j] = dist
				dmat._distmat[j][i] = dist
		return dmat

	def upgma(self):
		tree_nodes = [i for i in self.samples]
		distmat = self.distmat
		high_val = distmat.max()[0] + 1
		distmat.fill_diagonal(high_val)
		node_heights = {}

		while len(distmat) > 1:
			_, minloc = distmat.min()
			min_idx, max_idx = sorted([i for i in minloc])
			edge_len = distmat[min_idx][max_idx]
			min_name = tree_nodes[min_idx]
			max_name = tree_nodes[max_idx]
			# Adjust edge len to account for incorporated dists
			original_edge_len = edge_len
			min_edge = edge_len/2
			max_edge = edge_len/2
			if min_name in node_heights:
				min_edge = (edge_len/2) - node_heights[min_name]
			if max_name in node_heights:
				max_edge = (edge_len/2) - node_heights[max_name]

			# add to newick
			node = f"({min_name}:{round(min_edge, 2)},{max_name}:{round(max_edge, 2)})"
			node_heights[node] = original_edge_len/2
			tree_nodes[max_idx] = node
			del tree_nodes[min_idx]
			
			# update matrix with new values at max index row, column
			new_dists = distmat.average(min_idx, max_idx)
			distmat.set_row(max_idx ,new_dists)
			distmat.set_col(max_idx ,new_dists)
			distmat[max_idx][max_idx] = high_val

			# delete row, column at min index
			distmat.del_col(min_idx)
			distmat.del_row(min_idx)
			
		
		self._tree = tree_nodes[0]+";"
